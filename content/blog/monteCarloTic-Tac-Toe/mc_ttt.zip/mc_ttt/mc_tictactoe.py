"""
Monte Carlo Tic-Tac-Toe Player
"""

import random
import poc_ttt_gui
import poc_ttt_provided as provided

# Constants for Monte Carlo simulator
# Change as desired
NTRIALS = 1  # Number of trials to run
MCMATCH = 1.0  # Score for squares played by the machine player
MCOTHER = 1.0  # Score for squares played by the other player

# Add your functions here.
def mc_trial(board, player):
    """
    plays a complete game given the current board and the player to move
    """
    pass

def mc_update_scores(scores, board, player):
    """
    score the board and update the grid
    """
    pass

def get_best_move(board, scores):
    """
    return one of the squares with the maximum score
    """
    pass

def mc_move(board, player, trials):
    """
    returns a move for the machine player
    """
     pass


# Test game with the console or the GUI.
# Uncomment whichever you prefer.
# Both should be commented out when you submit for
# testing to save time.

#dimension = 3
#board = provided.TTTBoard(dimension)
#player = provided.PLAYERX

#provided.play_game(mc_move, NTRIALS, False)
#poc_ttt_gui.run_gui(dimension, player, mc_move, NTRIALS, False)
